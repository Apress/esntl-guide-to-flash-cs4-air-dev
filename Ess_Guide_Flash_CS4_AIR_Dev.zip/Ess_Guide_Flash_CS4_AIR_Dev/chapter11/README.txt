
Installation notes :
-------------------

Example 1 : Authentication Example:
------------------------------------
Run the example inside your Flash CS4 development environment and see that in the example you need to provide credentials for the server "aircookbook.com". When you uncomment following line, the credentials are set by default: 
URLRequestDefaults.setLoginCredentialsForHost("www.aircookbook.com",this.userName,this.userPass);


Example 2 : Follow Redirects Example:
--------------------------------------
Run the example inside your Flash CS4 development environment and experience that the image will not load inside the AIR application because of the redirected URL. When you set the followRedirects property of the URLRequest class to true, the load will succeed.


Example 3 : User Agent String Example :
----------------------------------------
Run the example inside your Flash CS4 development environment and experience what User Agent you are using. 


