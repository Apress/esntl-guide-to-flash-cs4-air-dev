function myOnMessage(aMessage)
{
    if (aMessage.length==1) {
        switch(aMessage[0]) 
        {
            case "ZoomIn":  
                zoom *= 2; 
                break;
            case "ZoomOut": 
                zoom /= 2; 
                break;
            default: 
                app.alert("Unknown message: " + aMessage[0]);
        }
    }
    else if (aMessage.length==2) {
        switch(aMessage[0]) 
        {
            case "GotoPage":  
                pageNum = aMessage[1]; 
                break;
            default: 
                app.alert("Unknown message: " + aMessage[0] + " - " + aMessage[1]);
        }
    }
    else
    {
        app.alert("Message from hostContainer: \n" + aMessage);
    }
}

function myOnDisclose(cURL,cDocumentURL)
{
    return true;
}

function myOnError(error, aMessage)
{
    app.alert(error);
}

var msgHandlerObject = new Object();
msgHandlerObject.onMessage = myOnMessage;
msgHandlerObject.onError = myOnError;
msgHandlerObject.onDisclose = myOnDisclose;

this.hostContainer.messageHandler = msgHandlerObject;